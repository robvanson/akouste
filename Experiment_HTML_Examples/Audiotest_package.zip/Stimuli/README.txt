Standard directory for storing Stimulus files
